

<?php $__env->startSection('content'); ?>

<body>
    <div class="container mt-4">
        <center><h1 class="my-4">Halaman Data Pegawai</h1></center>
        
        <div class="card mb-3">
            
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Jabatan</th>
                        <th>Umur</th>
                        <th>Alamat</th>
                    </tr>
                </thead>
                <tbody>
                    
                    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($p->nama); ?></td>
                            <td><?php echo e($p->jabatan); ?></td>
                            <td><?php echo e($p->umur); ?></td>
                            <td><?php echo e($p->alamat); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        
        <h2>Current Page: <?php echo e($pegawai->currentPage()); ?></h2><br>
        Jumlah Data: <?php echo e($pegawai->total()); ?><br>
        Data perhalaman: <?php echo e($pegawai->perPage()); ?><br>
        <br>
        <?php echo e($pegawai->links()); ?>

    </div>
</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\cobalaravel\resources\views/pegawai.blade.php ENDPATH**/ ?>